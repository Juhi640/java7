package com.mindtree.LibraryManagementSystem.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class FeedbackDto {

	private int feedbackId;

	private double rating;

	private String comment;

	@JsonIgnoreProperties("feedbackdto")
	private BookDto bookdto;

	public FeedbackDto() {
		super();
	}

	public FeedbackDto(int feedbackId, double rating, String comment, BookDto bookdto) {
		super();
		this.feedbackId = feedbackId;
		this.rating = rating;
		this.comment = comment;
		this.bookdto = bookdto;
	}

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public BookDto getBookdto() {
		return bookdto;
	}

	public void setBookdto(BookDto bookdto) {
		this.bookdto = bookdto;
	}

	@Override
	public String toString() {
		return "FeedbackDto [feedbackId=" + feedbackId + ", rating=" + rating + ", comment=" + comment + ", bookdto="
				+ bookdto + "]";
	}
	
	

}
