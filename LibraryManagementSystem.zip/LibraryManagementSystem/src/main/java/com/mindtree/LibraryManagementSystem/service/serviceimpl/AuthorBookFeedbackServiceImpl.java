package com.mindtree.LibraryManagementSystem.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.LibraryManagementSystem.dto.AuthorDto;
import com.mindtree.LibraryManagementSystem.dto.BookDto;
import com.mindtree.LibraryManagementSystem.dto.FeedbackDto;
import com.mindtree.LibraryManagementSystem.entity.Author;
import com.mindtree.LibraryManagementSystem.entity.Book;
import com.mindtree.LibraryManagementSystem.entity.Feedback;
import com.mindtree.LibraryManagementSystem.exception.bookNotFoundExceptin;
import com.mindtree.LibraryManagementSystem.repository.AuthorRepository;
import com.mindtree.LibraryManagementSystem.repository.BookRepository;
import com.mindtree.LibraryManagementSystem.repository.FeedbackRepository;
import com.mindtree.LibraryManagementSystem.service.AuthorBookFeedbackService;

@Service
public class AuthorBookFeedbackServiceImpl implements AuthorBookFeedbackService {

	@Autowired
	private AuthorRepository authorrepository;

	@Autowired
	private BookRepository bookrepository;

	@Autowired
	private FeedbackRepository feedbackrepository;

	@Override
	public AuthorDto insertAuthorIntoDB(AuthorDto authordto) {
		Author author = new Author();
		author.setAuthorId(authordto.getAuthorId());
		author.setAuthorName(authordto.getAuthorName());
		authorrepository.save(author);
		return authordto;
	}

	@Override
	public BookDto insertBookWithFeedbackIntoDB(BookDto bookdto, int author_id) {
		double sum = 0;
		Optional<Author> authors = authorrepository.findById(author_id);
		Author author = authors.get();
		List<Feedback> feedbacks = new ArrayList<>();
		Book book = new Book();
		book.setBookId(bookdto.getBookId());
		book.setBookName(bookdto.getBookName());
		book.setAuthor(author);
		for(FeedbackDto feedbackdto : bookdto.getFeedbackdto()){
			Feedback feedback = new Feedback();
			feedback.setFeedbackId(feedbackdto.getFeedbackId());
			feedback.setRating(feedbackdto.getRating());
			feedback.setComment(feedbackdto.getComment());
			feedback.setBook(book);
			feedbacks.add(feedback);
		}
		for (FeedbackDto feedbackdto : bookdto.getFeedbackdto()) {
			sum = sum + feedbackdto.getRating();
		}
		double avgrating = sum / bookdto.getFeedbackdto().size();
		book.setBookavgrating(avgrating);
		book.setFeedback(feedbacks);
		bookrepository.save(book);
		return bookdto;

	}

	@Override
	public AuthorDto dispalyAuthorNameFromDB(String book_name) throws bookNotFoundExceptin{
		//int found = 0;
		// List<Book> books = bookrepository.findAll();
		AuthorDto authordto = new AuthorDto();

		Book book = bookrepository.findAll().stream().filter(i -> i.getBookName().equalsIgnoreCase(book_name)).findAny()
				.orElseThrow(() -> new bookNotFoundExceptin("book not found"));
//		for (Book book : books) {
//			if (book.getBookName().equalsIgnoreCase(book_name)) {
//		
//				found = 1;
//				authordto.setAuthorName(book.getAuthor().getAuthorName());
//			}
//		}
		
		/*if (found == 0) {
			throw new bookNotFoundExceptin("book not found");
		}
		
*/		authordto.setAuthorName(book.getAuthor().getAuthorName());
		return authordto;

	}

	@Override
	public List<BookDto> displayBooksFromDB(){
		List<Book> books = bookrepository.findAll();
		List<BookDto> booksdto = new ArrayList<>();
		for (Book book : books){
			BookDto bookdto = new BookDto();
			bookdto.setBookId(book.getBookId());
			bookdto.setBookName(book.getBookName());
			bookdto.setBookavgrating(book.getBookavgrating());
			booksdto.add(bookdto);
		}

		return booksdto;

	}
}
