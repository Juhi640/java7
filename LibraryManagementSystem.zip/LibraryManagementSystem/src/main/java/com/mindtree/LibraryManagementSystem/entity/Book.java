package com.mindtree.LibraryManagementSystem.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookId;

	private String bookName;

	private double bookavgrating;

	@OneToMany(mappedBy = "book", cascade = CascadeType.ALL)
	private List<Feedback> feedback;

	@ManyToOne(fetch = FetchType.LAZY)
	private Author author;

	public Book() {
		super();
	}

	public Book(int bookId, String bookName, double bookavgrating, List<Feedback> feedback, Author author) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookavgrating = bookavgrating;
		this.feedback = feedback;
		this.author = author;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public double getBookavgrating() {
		return bookavgrating;
	}

	public void setBookavgrating(double bookavgrating) {
		this.bookavgrating = bookavgrating;
	}

	public List<Feedback> getFeedback() {
		return feedback;
	}

	public void setFeedback(List<Feedback> feedback) {
		this.feedback = feedback;
	}

	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", bookavgrating=" + bookavgrating + ", feedback="
				+ feedback + ", author=" + author + "]";
	}

}
