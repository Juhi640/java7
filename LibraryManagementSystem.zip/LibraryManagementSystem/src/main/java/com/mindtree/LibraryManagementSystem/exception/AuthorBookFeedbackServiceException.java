package com.mindtree.LibraryManagementSystem.exception;

public class AuthorBookFeedbackServiceException extends AuthorBookFeedbackAppException {

	public AuthorBookFeedbackServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AuthorBookFeedbackServiceException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public AuthorBookFeedbackServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public AuthorBookFeedbackServiceException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public AuthorBookFeedbackServiceException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
