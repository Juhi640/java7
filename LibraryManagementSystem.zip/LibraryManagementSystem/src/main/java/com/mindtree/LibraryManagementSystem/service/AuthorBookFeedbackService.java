package com.mindtree.LibraryManagementSystem.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.LibraryManagementSystem.dto.AuthorDto;
import com.mindtree.LibraryManagementSystem.dto.BookDto;
import com.mindtree.LibraryManagementSystem.dto.FeedbackDto;
import com.mindtree.LibraryManagementSystem.exception.bookNotFoundExceptin;

@Service
public interface AuthorBookFeedbackService {

	/**
	 * @param authordto
	 * @return
	 */
	public AuthorDto insertAuthorIntoDB(AuthorDto authordto);

	/**
	 * @param bookdto
	 * @param author_id
	 * @return
	 */
	public BookDto insertBookWithFeedbackIntoDB(BookDto bookdto, int author_id);

	/**
	 * @param book_name
	 * @return
	 * @throws bookNotFoundExceptin
	 */
	public AuthorDto dispalyAuthorNameFromDB(String book_name) throws bookNotFoundExceptin;

	/**
	 * @return
	 */
	public List<BookDto> displayBooksFromDB();

}
