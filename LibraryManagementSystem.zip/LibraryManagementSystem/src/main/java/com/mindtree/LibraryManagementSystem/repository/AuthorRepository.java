package com.mindtree.LibraryManagementSystem.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.mindtree.LibraryManagementSystem.entity.Author;

@Repository
public interface AuthorRepository extends JpaRepositoryImplementation<Author, Integer> {

}
