package com.mindtree.LibraryManagementSystem.controller.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.LibraryManagementSystem.controller.AppController;
import com.mindtree.LibraryManagementSystem.exception.bookNotFoundExceptin;

@RestControllerAdvice(assignableTypes = { AppController.class })
public class AppExceptionHandler {

	@ExceptionHandler(bookNotFoundExceptin.class)
	public ResponseEntity<String> serviceExceptionHandler(bookNotFoundExceptin e){
		
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
	}

}
