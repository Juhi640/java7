package com.mindtree.LibraryManagementSystem.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class BookDto implements Comparable<BookDto>{

	private int bookId;

	private String bookName;
	
	private double bookavgrating;
	

	@JsonIgnoreProperties("bookdto")
	private List<FeedbackDto> feedbackdto;

	@JsonIgnoreProperties("bookdto")
	private AuthorDto authordto;

	public BookDto() {
		super();
	}

	public BookDto(int bookId, String bookName, double bookavgrating, List<FeedbackDto> feedbackdto,
			AuthorDto authordto) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookavgrating = bookavgrating;
		this.feedbackdto = feedbackdto;
		this.authordto = authordto;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public double getBookavgrating() {
		return bookavgrating;
	}

	public void setBookavgrating(double bookavgrating) {
		this.bookavgrating = bookavgrating;
	}

	public List<FeedbackDto> getFeedbackdto() {
		return feedbackdto;
	}

	public void setFeedbackdto(List<FeedbackDto> feedbackdto) {
		this.feedbackdto = feedbackdto;
	}

	public AuthorDto getAuthordto() {
		return authordto;
	}

	public void setAuthordto(AuthorDto authordto) {
		this.authordto = authordto;
	}

	@Override
	public String toString() {
		return "BookDto [bookId=" + bookId + ", bookName=" + bookName + ", bookavgrating=" + bookavgrating
				+ ", feedbackdto=" + feedbackdto + ", authordto=" + authordto + "]";
	}

	@Override
	public int compareTo(BookDto b) {
		return (int) (b.getBookavgrating()-this.bookavgrating);
	}

	
}
