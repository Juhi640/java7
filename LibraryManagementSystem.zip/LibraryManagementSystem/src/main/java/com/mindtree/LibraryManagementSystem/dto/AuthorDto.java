package com.mindtree.LibraryManagementSystem.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class AuthorDto {

	private int authorId;

	private String authorName;

	@JsonIgnoreProperties("authordto")
	private List<BookDto> bookdto;

	public AuthorDto() {
		super();
	}

	public AuthorDto(int authorId, String authorName, List<BookDto> bookdto) {
		super();
		this.authorId = authorId;
		this.authorName = authorName;
		this.bookdto = bookdto;
	}

	public int getAuthorId() {
		return authorId;
	}

	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public List<BookDto> getBookdto() {
		return bookdto;
	}

	public void setBookdto(List<BookDto> bookdto) {
		this.bookdto = bookdto;
	}

	@Override
	public String toString() {
		return "AuthorDto [authorId=" + authorId + ", authorName=" + authorName + ", bookdto=" + bookdto + "]";
	}

}
