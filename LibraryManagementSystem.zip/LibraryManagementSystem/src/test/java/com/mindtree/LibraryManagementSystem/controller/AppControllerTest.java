package com.mindtree.LibraryManagementSystem.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import com.mindtree.LibraryManagementSystem.repository.AuthorRepository;

@RunWith(MockitoJUnitRunner.class)

class AppControllerTest {

	@Autowired
	private AuthorRepository authorrepository;
	
	@Test
	void test() {
		fail("Not yet implemented");
	}

}
